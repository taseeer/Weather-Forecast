// City array
const cities = [
  { lat: 52.367, lon: 4.904, name: 'Amsterdam, Netherlands' },
  { lat: 39.933, lon: 32.859, name: 'Ankara, Turkey' },
  { lat: 56.134, lon: 12.945, name: 'Åstorp, Sweden' },
  { lat: 37.983, lon: 23.727, name: 'Athens, Greece' },
  { lat: 54.597, lon: -5.93,	name: 'Belfast	Northern Ireland'}, 
  { lat: 41.387, lon:	2.168,	name: 'Barcelona	Spain'},
  { lat: 52.52,  lon:	13.405,  name:	'Berlin	Germany'},
  { lat: 46.948, lon: 7.447, name: 'Bern, Switzerland' },
  { lat: 43.263, lon: -2.935, name: 'Bilbao, Spain' },
  { lat: 50.847, lon: 4.357, name: 'Brussels, Belgium' },
  { lat: 47.497, lon: 19.04, name: 'Bucharest, Romania' },
  { lat: 59.329, lon: 18.068, name: 'Budapest, Hungary' },
  { lat: 51.483, lon: -3.168, name: 'Cardiff, Wales' },
  { lat: 50.937, lon: 6.96, name: 'Cologne, Germany' },
  { lat: 55.676, lon: 12.568, name: 'Copenhagen, Denmark' },
  { lat: 51.898, lon: -8.475, name: 'Cork, Ireland' },
  { lat: 53.349, lon: -6.26, name: 'Dublin, Ireland' },
  { lat: 55.953, lon: -3.188, name: 'Edinburgh, Scotland' },
  { lat: 43.7696, lon: 11.255, name: 'Florence, Italy' },
  { lat: 50.11, lon: 8.682, name: 'Frankfurt, Germany' },
  { lat: 43.254, lon: 6.637, name: 'French Riviera, France' },
  { lat: 32.65, lon: -16.908, name: 'Funchal, Portugal' },
  { lat: 36.14, lon: -5.353, name: 'Gibraltar' },
  { lat: 57.708, lon: 11.974, name: 'Gothenburg, Sweden' },
  { lat: 53.548, lon: 9.987, name: 'Hamburg, Germany' },
  { lat: 60.169, lon: 24.938, name: 'Helsinki, Finland' },
  { lat: 39.02, lon: 1.482, name: 'Ibiza, Spain' },
  { lat: 50.45, lon: 30.523, name: 'Kyiv, Ukraine' },
  { lat: 61.115, lon: 10.466, name: 'Lillehammer, Norway' },
  { lat: 38.722, lon: -9.139, name: 'Lisbon, Portugal' },
  { lat: 51.507, lon: -0.127, name: 'London, England' },
  { lat: 40.416, lon: -3.703, name: 'Madrid, Spain' },
  { lat: 39.695, lon: 3.017, name: 'Mallorca, Spain' },
  { lat: 53.48, lon: -2.242, name: 'Manchester, England' },
  { lat: 43.296, lon: 5.369, name: 'Marseille, France' },
  { lat: 27.76, lon: -15.586, name: 'Maspalomas, Spain' },
  { lat: 45.464, lon: 9.19, name: 'Milan, Italy' },
  { lat: 48.135, lon: 11.582, name: 'Munich, Germany' },
  { lat: 40.851, lon: 14.268, name: 'Naples, Italy' },
  { lat: 43.034, lon: -2.417, name: 'Oñati, Spain' },
  { lat: 59.913, lon: 10.752, name: 'Oslo, Norway' },
  { lat: 48.856, lon: 2.352, name: 'Paris, France' },
  { lat: 50.075, lon: 14.437, name: 'Prague, Czech Republic' },
  { lat: 64.146, lon: -21.942, name: 'Reykjavík, Iceland' },
  { lat: 56.879, lon: 24.603, name: 'Riga, Latvia' },
  { lat: 41.902, lon: 12.496, name: 'Rome, Italy' },
  { lat: 39.453, lon: -31.127, name: 'Santa Cruz das Flores, Portugal' },
  { lat: 28.463, lon: -16.251, name: 'Santa Cruz de Tenerife, Spain' },
  { lat: 57.273, lon: -6.215, name: 'Skye, Scotland' },
  { lat: 42.697, lon: 23.321, name: 'Sofia, Bulgaria' },
  { lat: 59.329, lon: 18.068, name: 'Stockholm, Sweden' },
  { lat: 59.437, lon: 24.753, name: 'Tallinn, Estonia' },
  { lat: 48.208, lon: 16.373, name: 'Vienna, Austria' },
  { lat: 52.229, lon: 21.012, name: 'Warsaw, Poland' },
  { lat: 53.961, lon: -1.07, name: 'York, England' },
  { lat: 47.376, lon: 8.541, name: 'Zurich, Switzerland' }


  // Add more cities here
];

// API Key
const apiKey = "Login_openweather_get_API";

// Unit state (default is Celsius)
let isCelsius = true;

// DOM Elements
const citySelect = document.querySelector('.city-select');
const unitToggle = document.getElementById('unit-toggle');
const weatherContainer = document.getElementById('weather-container');

// Populate the dropdown
cities.forEach(city => {
  const option = document.createElement('option');
  option.value = `${city.lat},${city.lon}`;
  option.textContent = city.name;
  citySelect.appendChild(option);
});

// Event listener for city selection
citySelect.addEventListener('change', () => {
  const [lat, lon] = citySelect.value.split(',');
  fetchWeather(lat, lon);
});

// Event listener for unit toggle
unitToggle.addEventListener('click', () => {
  isCelsius = !isCelsius; // Toggle unit
  unitToggle.textContent = isCelsius ? "Change to Fahrenheit" : "Change to Celsius";
  const [lat, lon] = citySelect.value.split(',');
  if (lat && lon) {
    fetchWeather(lat, lon); // Re-fetch weather data with updated unit
  }
});

// Fetch weather data
function fetchWeather(lat, lon) {
  const unit = isCelsius ? "metric" : "imperial";
  fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=${unit}`)
    .then(response => response.json())
    .then(data => displayWeather(data))
    .catch(error => console.error('Error fetching weather data:', error));
}

// Function to map OpenWeather icons to custom images
function getWeatherImage(weatherCondition) {
  const iconMapping = {
    'clear': 'clear.png',
    'clouds': 'cloudy.png',
    'fog': 'fog.png',
    'rain': 'rain.png',
    'snow': 'snow.png',
    'humid': 'humid.png',
    'shower': 'ishower.png',
    'light rain': 'lightrain.png',
    'mcloudy': 'mcloudy.png',
    'oshower': 'oshower.png',
    'pcloudy': 'pcloudy.png',
    'rainsnow': 'rainsnow.png',
    'tsrain': 'tsrain.png',
    'tstorm': 'tstorm.png',
    'windy': 'windy.png'
  };

  // Convert the condition to lowercase for consistency
  const lowerCondition = weatherCondition.toLowerCase();

  // Partial matching to find the most suitable icon
  for (const key in iconMapping) {
    if (lowerCondition.includes(key)) {
      return iconMapping[key];
    }
  }

  return 'default.png'; // Default image if no match
}

// Display weather data
function displayWeather(data) {
  weatherContainer.innerHTML = ''; // Clear previous data

  // Loop through the data to display the 7-day forecast
  for (let i = 0; i < 7; i++) {
    const start = i * 8; // Start index for the day's forecast (every 24 hours)
    const end = start + 8; // End index (next 8 data points for the day)

    // Extract the daily forecast data points
    const dailyForecast = data.list.slice(start, end);

    // Calculate tempHigh and tempLow manually
    const tempHigh = Math.max(...dailyForecast.map(f => f.main.temp_max));
    const tempLow = Math.min(...dailyForecast.map(f => f.main.temp_min));

    const date = new Date(dailyForecast[0].dt * 1000);
    const dayName = date.toLocaleString('en-US', { weekday: 'short' });
    const monthDay = `${date.getDate()} ${date.toLocaleString('en-US', { month: 'short' })}`;
    const weatherDescription = dailyForecast[0].weather[0]?.description || "No description";
    const weatherCondition = dailyForecast[0].weather[0]?.main || "Unknown";
    const weatherImage = getWeatherImage(weatherCondition); // Get corresponding image

    // Create a weather card
    const weatherCard = document.createElement('div');
    weatherCard.className = 'weather-card';
    weatherCard.innerHTML = `
      <div class="weather-card-header">
        <div class="day">${dayName}</div>
        <div class="date">${monthDay}</div>
        <img src="images/${weatherImage}" alt="${weatherDescription}">
      </div>
      <div class="weather-card-body">
        <div class="description">${weatherDescription}</div><br>
        <div class="temp">H: ${isCelsius ? `${tempHigh}°C` : `${convertToFahrenheit(tempHigh)}°F`} <br> L: ${isCelsius ? `${tempLow}°C` : `${convertToFahrenheit(tempLow)}°F`}</div>
      </div>
    `;
    weatherContainer.appendChild(weatherCard);
  }
}

// Helper function to convert Celsius to Fahrenheit
function convertToFahrenheit(celsius) {
  return ((celsius * 9) / 5 + 32).toFixed(1);
}